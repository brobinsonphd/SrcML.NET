int foo = 0;
printf("hello world %d", foo);

int main(int argc, char* argv[]) {
    int foo = 17;
    
    foo = 42;
    return foo;
}
