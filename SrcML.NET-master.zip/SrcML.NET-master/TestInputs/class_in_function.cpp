int foo();

int main() {
    A a;
  a.a = 5;
  a.b = 10;
  return 0;
}

int foo() {
  class A {public: int a; int b; };
  A a;
  a.a = 5;
  a.b = 10;
  retu
}
