int main(){ }

int Foo() { }
