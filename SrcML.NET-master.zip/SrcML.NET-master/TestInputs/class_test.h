
class TestClass {
 public:
  int set_x(int val);
  int set_y(int y);
  int z;
 private:
  int x;
  int y;
};

