
namespace A {
  void foo();

  namespace nested {
    int bar = 42;
  }
}
