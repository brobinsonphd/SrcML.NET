
namespace A {
class Foo {
  public:
    int a;
    int Add(int b);
  };
}
