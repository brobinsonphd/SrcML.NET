#include <iostream>
int main() {
  for(int i = 0; i < 10; i++){// variable declaration (i)
    std::cout << i << std::endl;// variable use (i)
  }
  return 0;
}
