#include<iostream>

int main(int argc, char* argv[]){
    std::cout<<"args passed: "<<argc<<std::endl;
    return 0;
}
