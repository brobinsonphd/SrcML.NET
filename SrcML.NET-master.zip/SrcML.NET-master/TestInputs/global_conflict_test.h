class A {
  int X;
 public:
  A() { X = 5; }
  int GetX();
};
