#include "A.h"

using namespace A;
int Foo::Add(int b) {
  return this->a + b;
}
