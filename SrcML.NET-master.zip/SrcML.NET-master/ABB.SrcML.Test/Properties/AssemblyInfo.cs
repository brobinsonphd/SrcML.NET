﻿using System.Reflection;
using System.Runtime.InteropServices;
using System;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("SrcMLFrameworkTest")]
[assembly: AssemblyProduct("SrcMLFrameworkTest")]
[assembly: AssemblyDescription("")]

[assembly: AssemblyCopyright("Copyright © ABB 2011")]

[assembly: CLSCompliant(true)]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("72cc3dad-f5f3-4e87-be97-46c581a9252c")]
