﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("ABB.SrcML.Tools.DataTester")]
[assembly: AssemblyProduct("ABB.SrcML.Tools.DataTester")]
[assembly: AssemblyDescription("")]

[assembly: AssemblyCopyright("Copyright © ABB 2013")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("47bbb1b5-7da8-4ff1-ac4e-b04753871acd")]

