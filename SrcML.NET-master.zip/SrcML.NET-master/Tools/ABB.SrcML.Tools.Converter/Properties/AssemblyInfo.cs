﻿/******************************************************************************
 * Copyright (c) 2010 ABB Group
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *    Vinay Augustine (ABB Group) - initial API, implementation, & documentation
 *****************************************************************************/

using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("SrcMLCommand")]
[assembly: AssemblyProduct("SrcMLCommand")]
[assembly: AssemblyDescription("")]

[assembly: AssemblyCopyright("Copyright © ABB 2010")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("69a0de6a-7852-4e2a-b987-677d53c76052")]
