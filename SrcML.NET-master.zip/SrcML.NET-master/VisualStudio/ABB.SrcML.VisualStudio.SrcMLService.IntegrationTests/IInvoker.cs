﻿namespace ABB.SrcML.VisualStudio.SrcMLService.IntegrationTests {
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// TODO: Update summary.
    /// </summary>
    public interface IInvoker {
        void Invoke(System.Windows.Forms.MethodInvoker globalSystemWindowsFormsMethodInvoker);
    }
}
