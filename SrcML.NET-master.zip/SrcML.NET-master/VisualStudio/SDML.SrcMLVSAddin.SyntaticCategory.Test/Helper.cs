﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SDML.SrcMLVSAddin.SyntaticCategory.Test
{
    class Helper
    {
        public static string NppXmlPath = @"..\..\TestInputs\npp-5.9.4.xml";
    }
}
